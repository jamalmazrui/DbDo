﻿; DbDo.jss -- JAWS scripts for DbDo.exe
;
; Purpose: define a single Script, PassDbDoKey, that the companion
; DbDo.jkm file references to hand certain keystrokes straight to
; DbDo instead of running JAWS's default handler for them.
;
; Why this stops JAWS speaking the key name: when a key such as
; Backspace (DbDo's Exit-Child command in the data grid) has no
; script bound for the app, JAWS falls back to announcing the key
; by name. Binding it to this script makes JAWS treat the key as
; handled, so the name is not spoken; DbDo supplies its own spoken
; feedback for the command.
;
; Why normal editing still works outside the grid: the body is the
; JAWS built-in Function TypeCurrentScriptKey(), which passes the
; keystroke to the focused control as if no script ran. JAWS's
; character echo follows the control's text change, not this
; script, so in an edit field Backspace and Delete still speak the
; character they remove. A key map's right-hand side must name a
; Script (not a Function), which is why this one-line wrapper exists.
;
; This file has no Include or Use dependencies, so scompile.exe can
; build it against any installed JAWS version. The DbDo installer
; compiles it into each JAWS year-version settings folder so the
; binary matches the JAWS version that loads it.

Script PassDbDoKey ()
TypeCurrentScriptKey ()
EndScript
